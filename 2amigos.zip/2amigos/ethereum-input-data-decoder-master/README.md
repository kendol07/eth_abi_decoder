# Run the example

`sh decode.sh`