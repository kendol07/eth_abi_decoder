#!/bin/bash

php -f examples/decode.php